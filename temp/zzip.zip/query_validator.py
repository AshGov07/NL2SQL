# # query_validator.py

# import re


# class QueryValidator:

#     @staticmethod
#     def validate(sql, schema_df):

#         sql_lower = sql.lower()

#         tables = set(
#             schema_df["TABLE_NAME"].str.lower()
#         )

#         columns = set(
#             schema_df["COLUMN_NAME"].str.lower()
#         )

#         # -----------------------------
#         # Validate tables
#         # -----------------------------

#         found_tables = re.findall(
#             r'(?:from|join)\s+([a-zA-Z_][a-zA-Z0-9_]*)',
#             sql_lower
#         )

#         for table in found_tables:

#             if table not in tables:

#                 raise ValueError(
#                     f"Unknown table detected: {table}"
#                 )

#         # -----------------------------
#         # Validate columns
#         # -----------------------------

#         found_columns = re.findall(
#             r'([a-zA-Z_][a-zA-Z0-9_]*)\.',
#             sql
#         )

#         # aliases ignored in v1

#         return True

#         # -----------------------------
#         # Validate columns
#         # -----------------------------

        

#         found_column_candidates = re.findall(
#             r"select\s+(.*?)\s+from",
#             sql_lower,
#             re.DOTALL
#         )

#         if found_column_candidates:

#             select_part = found_column_candidates[0]

#             columns_found = re.findall(
#                 r"[a-zA-Z_][a-zA-Z0-9_]*",
#                 select_part
#             )

#             sql_keywords = {
#                 "select",
#                 "from",
#                 "distinct",
#                 "count",
#                 "sum",
#                 "avg",
#                 "min",
#                 "max",
#                 "as"
#             }

#             for col in columns_found:

#                 if col in sql_keywords:
#                     continue

#                 if col not in columns:

#                     raise ValueError(
#                         f"Unknown column detected: {col}"
#                     )





#version 2 (correctly working after phase 5b)
# query_validator.py

# import re

# class QueryValidator:

#     SQL_KEYWORDS = {
#         "select",
#         "from",
#         "where",
#         "join",
#         "inner",
#         "left",
#         "right",
#         "outer",
#         "on",
#         "group",
#         "by",
#         "order",
#         "having",
#         "limit",
#         "distinct",
#         "count",
#         "sum",
#         "avg",
#         "min",
#         "max",
#         "as",
#         "and",
#         "or",
#         "not",
#         "with",
#         "asc",
#         "desc"
#     }

#     @staticmethod
#     def validate(sql, schema_df):

#         sql_lower = sql.lower()

#         tables = set(
#             schema_df["TABLE_NAME"]
#             .str.lower()
#             .tolist()
#         )

#         columns = set(
#             schema_df["COLUMN_NAME"]
#             .str.lower()
#             .tolist()
#         )

#         # ----------------------------------------
#         # TABLE VALIDATION
#         # ----------------------------------------

#         found_tables = re.findall(
#             r'(?:from|join)\s+([a-zA-Z_][a-zA-Z0-9_]*)',
#             sql_lower
#         )

#         for table in found_tables:

#             if table not in tables:

#                 raise ValueError(
#                     f"Unknown table detected: {table}"
#                 )

#         print("Table Validation Passed")

#         # ----------------------------------------
#         # COLUMN VALIDATION
#         # ----------------------------------------

#         select_match = re.search(
#             r"select\s+(.*?)\s+from",
#             sql_lower,
#             re.IGNORECASE | re.DOTALL
#         )

#         if select_match:

#             select_part = select_match.group(1)

#             candidate_columns = re.findall(
#                 r"[a-zA-Z_][a-zA-Z0-9_]*",
#                 select_part
#             )

#             for col in candidate_columns:

#                 if col in QueryValidator.SQL_KEYWORDS:
#                     continue

#                 if col not in columns:

#                     raise ValueError(
#                         f"Unknown column detected: {col}"
#                     )

#         print("Column Validation Passed")

#         return True



# query_validator.py

import re


class QueryValidator:

    # SQL_KEYWORDS = {
    #     "select",
    #     "from",
    #     "where",
    #     "join",
    #     "inner",
    #     "left",
    #     "right",
    #     "outer",
    #     "on",
    #     "group",
    #     "by",
    #     "order",
    #     "having",
    #     "limit",
    #     "distinct",
    #     "count",
    #     "sum",
    #     "avg",
    #     "min",
    #     "max",
    #     "as",
    #     "and",
    #     "or",
    #     "not",
    #     "with",
    #     "asc",
    #     "desc"
    # }

    SQL_KEYWORDS = {
        "select",
        "from",
        "where",
        "join",
        "inner",
        "left",
        "right",
        "outer",
        "on",
        "group",
        "by",
        "order",
        "having",
        "limit",
        "distinct",
        "count",
        "sum",
        "avg",
        "min",
        "max",
        "as",
        "and",
        "or",
        "not",
        "is",
        "null",
        "with",
        "asc",
        "desc",
        "between",
        "like",
        "in",
        "exists"
    }

    @staticmethod
    def validate_tables(sql_lower, tables):

        found_tables = re.findall(
            r'(?:from|join)\s+([a-zA-Z_][a-zA-Z0-9_]*)',
            sql_lower
        )

        for table in found_tables:

            if table not in tables:

                raise ValueError(
                    f"Unknown table detected: {table}"
                )

        print("Table Validation Passed")

    @staticmethod
    def validate_columns(
        sql,
        sql_lower,
        columns
    ):

        select_match = re.search(
            r"select\s+(.*?)\s+from",
            sql_lower,
            re.IGNORECASE | re.DOTALL
        )

        if not select_match:
            return

        select_part = select_match.group(1)

        candidate_columns = re.findall(
            r"[a-zA-Z_][a-zA-Z0-9_]*",
            select_part
        )

        for col in candidate_columns:

            if col in QueryValidator.SQL_KEYWORDS:
                continue

            if col not in columns:

                raise ValueError(
                    f"Unknown column detected: {col}"
                )

        print("Column Validation Passed")

    @staticmethod
    def validate(sql, schema_df,relationship_df):

        sql_lower = sql.lower()

        tables = set(
            schema_df["TABLE_NAME"]
            .str.lower()
            .tolist()
        )

        columns = set(
            schema_df["COLUMN_NAME"]
            .str.lower()
            .tolist()
        )

        QueryValidator.validate_tables(
            sql_lower,
            tables
        )
        
        aliases = QueryValidator.extract_aliases(sql_lower)
        # print("Aliases:", aliases)

        if len(aliases) == 0:

            QueryValidator.validate_columns(
                sql,
                sql_lower,
                columns
            )
        # QueryValidator.validate_columns(
        #     sql,
        #     sql_lower,
        #     columns
        # )

        

        QueryValidator.validate_qualified_columns(
            sql,
            aliases,
            schema_df
        )
        QueryValidator.validate_joins(
            sql,
            aliases,
            relationship_df
        )
        return True
    
    # @staticmethod
    # def extract_aliases(sql_lower):

    #     aliases = {}

    #     matches = re.findall(
    #         r'(?:from|join)\s+(\w+)\s+(\w+)',
    #         sql_lower
    #     )

    #     for table, alias in matches:

    #         aliases[alias] = table

    #     return aliases



    @staticmethod
    def extract_aliases(sql_lower):

        aliases = {}

        # sql_keywords = {
        #     "where",
        #     "group",
        #     "order",
        #     "having",
        #     "limit",
        #     "join",
        #     "inner",
        #     "left",
        #     "right",
        #     "outer",
        #     "on",
        #     "and",
        #     "or",
        #     "not",
        #     "by",
        #     "asc",
        #     "desc"
        # }

        matches = re.findall(
            r'(?:from|join)\s+([a-zA-Z_][a-zA-Z0-9_]*)'
            r'(?:\s+([a-zA-Z_][a-zA-Z0-9_]*))?',
            sql_lower,
            re.IGNORECASE
        )

        for table_name, alias in matches:

            if not alias:
                continue

            if alias.lower() in QueryValidator.SQL_KEYWORDS:
                continue

            aliases[alias.lower()] = table_name.lower()

        print("Aliases:", aliases)

        return aliases
    
    @staticmethod
    def validate_qualified_columns(
        sql,
        aliases,
        schema_df
    ):  

        qualified_columns = re.findall(
            r'(\w+)\.(\w+)',
            sql
        )

        for alias, column in qualified_columns:

            alias = alias.lower()
            column = column.lower()

            if alias not in aliases:

                raise ValueError(
                    f"Unknown alias detected: {alias}"
                )

            table = aliases[alias]

            exists = (
                (
                    schema_df["TABLE_NAME"]
                    .str.lower() == table
                )
                &
                (
                    schema_df["COLUMN_NAME"]
                    .str.lower() == column
                )
            ).any()

            if not exists:

                raise ValueError(
                    f"Unknown column {table}.{column}"
                )

        print("Qualified Column Validation Passed")
    
    @staticmethod
    def validate_joins(sql,aliases,relationship_df):
        join_conditions = re.findall(
            r'(\w+)\.(\w+)\s*=\s*(\w+)\.(\w+)',
            sql,
            re.IGNORECASE
        )

        for left_alias, left_col, right_alias, right_col in join_conditions:

            left_alias = left_alias.lower()
            right_alias = right_alias.lower()

            left_col = left_col.lower()
            right_col = right_col.lower()

            if left_alias not in aliases:
                raise ValueError(
                    f"Unknown alias: {left_alias}"
                )

            if right_alias not in aliases:
                raise ValueError(
                    f"Unknown alias: {right_alias}"
                )

            left_table = aliases[left_alias]
            right_table = aliases[right_alias]

            valid = False

            for _, row in relationship_df.iterrows():

                table_name = row["TABLE_NAME"].lower()
                column_name = row["COLUMN_NAME"].lower()

                ref_table = row[
                    "REFERENCED_TABLE_NAME"
                ].lower()

                ref_column = row[
                    "REFERENCED_COLUMN_NAME"
                ].lower()

                forward_match = (
                    table_name == left_table
                    and column_name == left_col
                    and ref_table == right_table
                    and ref_column == right_col
                )

                reverse_match = (
                    table_name == right_table
                    and column_name == right_col
                    and ref_table == left_table
                    and ref_column == left_col
                )

                if forward_match or reverse_match:

                    valid = True
                    break

            if not valid:

                raise ValueError(
                    f"Invalid join detected: "
                    f"{left_table}.{left_col} = "
                    f"{right_table}.{right_col}"
                )

        print("Join Validation Passed")