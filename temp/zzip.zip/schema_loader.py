# from vanna.integrations.mysql import MySQLRunner
# import pandas as pd


# class SchemaLoader:

#     def __init__(self, runner):
#         self.runner = runner

#     def get_schema_context(self):

#         query = """
#         SELECT
#             TABLE_NAME,
#             COLUMN_NAME,
#             DATA_TYPE
#         FROM INFORMATION_SCHEMA.COLUMNS
#         WHERE TABLE_SCHEMA = DATABASE()
#         ORDER BY TABLE_NAME, ORDINAL_POSITION;
#         """

#         import pymysql

#         conn = pymysql.connect(
#             host=self.runner.host,
#             user=self.runner.user,
#             password=self.runner.password,
#             database=self.runner.database,
#             port=self.runner.port
#         )

#         df = pd.read_sql(query, conn)

#         schema_text = []

#         current_table = None

#         for _, row in df.iterrows():

#             table = row["TABLE_NAME"]

#             if table != current_table:

#                 current_table = table

#                 schema_text.append(f"\n{table}")
#                 schema_text.append("-" * len(table))

#             schema_text.append(
#                 f"{row['COLUMN_NAME']} ({row['DATA_TYPE']})"
#             )

#         conn.close()

#         return "\n".join(schema_text)


# schema_loader.py

import pandas as pd
import pymysql


class SchemaLoader:

    def __init__(
        self,
        host,
        user,
        password,
        database,
        port=3306
    ):
        self.host = host
        self.user = user
        self.password = password
        self.database = database
        self.port = port

    def get_schema_context(self):

        query = """
        SELECT
            TABLE_NAME,
            COLUMN_NAME,
            DATA_TYPE
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
        ORDER BY TABLE_NAME, ORDINAL_POSITION;
        """

        conn = pymysql.connect(
            host=self.host,
            user=self.user,
            password=self.password,
            database=self.database,
            port=self.port
        )

        df = pd.read_sql(query, conn)

        schema_text = []

        current_table = None

        for _, row in df.iterrows():

            table = row["TABLE_NAME"]

            if table != current_table:

                current_table = table

                schema_text.append("\n")
                schema_text.append(table)
                schema_text.append("-" * len(table))

            schema_text.append(
                f"{row['COLUMN_NAME']} ({row['DATA_TYPE']})"
            )

        conn.close()

        return "\n".join(schema_text)

    #phase 3- FK discovery
    def get_relationships(self):

        query = """
        SELECT
            TABLE_NAME,
            COLUMN_NAME,
            REFERENCED_TABLE_NAME,
            REFERENCED_COLUMN_NAME
        FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
        WHERE TABLE_SCHEMA = DATABASE()
        AND REFERENCED_TABLE_NAME IS NOT NULL
        ORDER BY TABLE_NAME;
        """

        conn = pymysql.connect(
            host=self.host,
            user=self.user,
            password=self.password,
            database=self.database,
            port=self.port
        )

        df = pd.read_sql(query, conn)

        conn.close()

        relationships = []

        for _, row in df.iterrows():

            relationships.append(
                f"{row['TABLE_NAME']}.{row['COLUMN_NAME']} "
                f"-> "
                f"{row['REFERENCED_TABLE_NAME']}."
                f"{row['REFERENCED_COLUMN_NAME']}"
            )

        return "\n".join(relationships) 

    #phase 5c
    def get_relationship_dataframe(self):

        query = """
        SELECT
            TABLE_NAME,
            COLUMN_NAME,
            REFERENCED_TABLE_NAME,
            REFERENCED_COLUMN_NAME
        FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
        WHERE TABLE_SCHEMA = DATABASE()
        AND REFERENCED_TABLE_NAME IS NOT NULL;
        """

        conn = pymysql.connect(
            host=self.host,
            user=self.user,
            password=self.password,
            database=self.database,
            port=self.port
        )

        df = pd.read_sql(query, conn)

        conn.close()

        return df
    
    #phase4B automatic business logic

    def get_schema_dataframe(self):

        query = """
        SELECT
            TABLE_NAME,
            COLUMN_NAME,
            DATA_TYPE
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
        """

        conn = pymysql.connect(
            host=self.host,
            user=self.user,
            password=self.password,
            database=self.database,
            port=self.port
        )

        df = pd.read_sql(query, conn)

        conn.close()

        return df