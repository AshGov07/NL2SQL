# safe_mysql_runner.py

from vanna.integrations.mysql import MySQLRunner
from sql_guard import SQLGuard


class SafeMySQLRunner(MySQLRunner):

    async def run_sql(self, args, context):

        SQLGuard.validate(args.sql)

        return await super().run_sql(args, context)